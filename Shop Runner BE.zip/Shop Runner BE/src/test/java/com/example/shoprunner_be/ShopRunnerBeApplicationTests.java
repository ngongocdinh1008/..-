package com.example.shoprunner_be;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopRunnerBeApplicationTests {

	@Test
	void contextLoads() {
	}

}
