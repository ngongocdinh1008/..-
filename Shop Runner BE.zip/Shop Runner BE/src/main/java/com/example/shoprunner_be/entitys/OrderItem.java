package com.example.shoprunner_be.entitys;

import com.example.shoprunner_be.entitys.Product.Product;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.FieldDefaults;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "order_item")
@Data
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
@Builder
public class OrderItem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;

    String name;

    int price;

    int discount;

    int quantity;

    @Column(name = "sum_price")
    double sumPrice;

    String description;

    boolean isFavorite;
    @OneToMany(mappedBy = "orderItem", orphanRemoval = true)
    private List<Product> products = new ArrayList<>();
    @ManyToOne
    @JoinColumn(name = "order_id")
    Order order;
    @PrePersist
    public void prePersist() {
        this.price = 0;
        this.discount = 1;
        this.quantity = 1;
        this.sumPrice = 0;
    }
}
