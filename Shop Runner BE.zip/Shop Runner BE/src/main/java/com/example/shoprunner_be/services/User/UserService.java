package com.example.shoprunner_be.services.User;

import com.example.shoprunner_be.dtos.UserDTO;
import com.example.shoprunner_be.dtos.UserLoginDTO;
import com.example.shoprunner_be.entitys.User;

import java.util.Optional;

public interface UserService {
    User createUser(UserDTO userDTO) throws Exception;

    Optional<User> login(UserLoginDTO userLoginDTO);
}
