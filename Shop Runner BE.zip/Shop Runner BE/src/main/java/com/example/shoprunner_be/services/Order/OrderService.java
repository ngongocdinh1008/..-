package com.example.shoprunner_be.services.Order;

public interface OrderService {
    void addProductToOrder(Long productId, Long orderId);
    void removeProductFromOrder(Long orderId, Long productId);
    void getAllProductsFromOrder(Long orderId);
}
