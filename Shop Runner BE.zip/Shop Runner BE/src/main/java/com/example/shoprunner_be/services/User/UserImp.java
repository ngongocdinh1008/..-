package com.example.shoprunner_be.services.User;

import com.example.shoprunner_be.dtos.UserDTO;
import com.example.shoprunner_be.dtos.UserLoginDTO;
import com.example.shoprunner_be.entitys.Role;
import com.example.shoprunner_be.entitys.User;
import com.example.shoprunner_be.exceptions.Dataintegrityviolationexception;
import com.example.shoprunner_be.repositories.RoleRepo;
import com.example.shoprunner_be.repositories.UserRepo;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class UserImp implements UserService{
    @Autowired
    UserRepo userRepo;
    @Autowired
    RoleRepo roleRepo;
    @Autowired
    PasswordEncoder passwordEncoder;

    @Override
    public User createUser(UserDTO userDTO) {
        if (userRepo.existsByPhoneNumber(userDTO.getPhoneNumber())) {
            throw new Dataintegrityviolationexception("Phone number already in use");
        }
        User user = User.builder()
                .name(userDTO.getName())
                .phoneNumber(userDTO.getPhoneNumber())
                .createdAt(LocalDateTime.now())
                .build();
        user.setPassword(passwordEncoder.encode(userDTO.getPassword()));
        if(userDTO.getRoleID() != null) {
            Role defaultRole = roleRepo.findByName("USER").orElse(null);
            user.setRole(defaultRole);
        }
        return userRepo.save(user);
    }

    @Override
    public Optional<User> login(UserLoginDTO userLoginDTO) {
        // Kiểm tra xem userLoginDTO có null không
        if (userLoginDTO == null) {
            throw new IllegalArgumentException("UserLoginDTO cannot be null");
        }

        String phoneNumber = userLoginDTO.getPhoneNumber();
        String password = userLoginDTO.getPassword();

        // Kiểm tra xem phoneNumber và password có null không
        if (phoneNumber == null || phoneNumber.isEmpty() || password == null || password.isEmpty()) {
            throw new IllegalArgumentException("PhoneNumber and password cannot be null or empty");
        }

        Optional<User> userOptional = userRepo.findByPhoneNumber(phoneNumber);

        if (userOptional.isEmpty()) {
            return Optional.empty();
        }

        User user = userOptional.get();

        // Xác thực mật khẩu
        if (passwordEncoder.matches(password, user.getPassword())) {
            return Optional.of(user);
        } else {
            return Optional.empty();
        }
    }


}
