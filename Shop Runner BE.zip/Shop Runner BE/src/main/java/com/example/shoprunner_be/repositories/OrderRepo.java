package com.example.shoprunner_be.repositories;

import com.example.shoprunner_be.entitys.Order;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface OrderRepo extends JpaRepository<Order, Long> {
    Optional<Order> findById(Long id);
}
