//package com.example.shoprunner_be.controllers;
//
//import com.example.shoprunner_be.entitys.Order;
//import com.example.shoprunner_be.exceptions.EntityNotFoundException;
//import com.example.shoprunner_be.repositories.OrderRepo;
//import com.example.shoprunner_be.services.Order.OrderService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.List;
//
//@RestController
//@RequestMapping("${api.prefix}/order")
//public class OrderController {
//    @Autowired
//    private OrderService orderService;
//
//    @Autowired
//    private OrderRepo orderRepo;
//
//    @PostMapping("/{orderId}/add-product/{productId}")
//    public ResponseEntity<Order> addProductToOrder(
//            @PathVariable Long orderId,
//            @PathVariable Long productId
//    ) {
//        orderService.addProductToOrder(orderId, productId);
//        return ResponseEntity.ok(orderRepo.findById(orderId).orElse(null));
//    }
//
//    @DeleteMapping("/{orderId}/remove-product/{productId}")
//    public ResponseEntity<Order> removeProductFromOrder(
//            @PathVariable Long orderId,
//            @PathVariable Long productId) {
//        orderService.removeProductFromOrder(orderId, productId);
//        return ResponseEntity.ok(orderRepo.findById(orderId).orElse(null));
//    }
//    @GetMapping
//    public ResponseEntity<List<Order>> getAllOrders() {
//        return ResponseEntity.ok(orderRepo.findAll());
//    }
//
//    @ExceptionHandler(EntityNotFoundException.class)
//    public ResponseEntity<String> handleEntityNotFoundException(EntityNotFoundException e) {
//        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
//    }
//}