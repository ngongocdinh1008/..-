package com.example.shoprunner_be.configurations;

import com.example.shoprunner_be.entitys.User;
import io.jsonwebtoken.Jwts;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

@Component
public class JwtUtils {
    private String generateToken(User user) {
        return Jwts.builder()
                .setSubject(user.getUsername())
                .
                .compact();
    }
}
