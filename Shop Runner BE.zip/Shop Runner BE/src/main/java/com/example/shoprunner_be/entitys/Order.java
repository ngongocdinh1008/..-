package com.example.shoprunner_be.entitys;
import com.example.shoprunner_be.entitys.Product.Product;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.FieldDefaults;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "orders")
@Data
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
@Builder
public class Order {
    @Id
    Long id;

    @Column(name = "order_date")
    LocalDateTime orderDate;

    @Column(name = "temporary_price")
    double temporaryPrice;

    @Column(name = "total_discount")
    double totalDiscount;

    @Column(name = "total_price")
    double totalPrice;

    @ManyToOne
    User user;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    List<OrderItem> items;

    @PrePersist
    public void prePersist() {
        this.id = 0L;
        this.orderDate = LocalDateTime.now();
        this.temporaryPrice = 0;
        this.totalDiscount = 0;
        this.totalPrice = 0;
    }
}