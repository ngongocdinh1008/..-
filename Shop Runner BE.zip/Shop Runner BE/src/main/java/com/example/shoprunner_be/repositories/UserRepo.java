package com.example.shoprunner_be.repositories;

import com.example.shoprunner_be.entitys.User;
import org.springframework.data.repository.CrudRepository;

import java.util.Optional;

public interface UserRepo extends CrudRepository<User, Long> {
    boolean existsByPhoneNumber(String PhoneNumber);
    Optional<User> findByPhoneNumber(String phoneNumber);
}
