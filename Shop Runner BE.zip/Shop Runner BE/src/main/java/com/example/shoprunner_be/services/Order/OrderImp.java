//package com.example.shoprunner_be.services.Order;
//
//import com.example.shoprunner_be.entitys.Order;
//import com.example.shoprunner_be.entitys.OrderItem;
//import com.example.shoprunner_be.entitys.Product.Product;
//import com.example.shoprunner_be.exceptions.EntityNotFoundException;
//import com.example.shoprunner_be.repositories.OrderRepo;
//import com.example.shoprunner_be.repositories.ProductRepo;
//import com.example.shoprunner_be.responses.Order.CalculatePrices;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;
//
//import java.time.LocalDateTime;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Optional;
//
//@Service
//public class OrderImp implements OrderService{
//    @Autowired
//    private OrderRepo orderRepo;
//    @Autowired
//    private ProductRepo productRepo;
//
//    @Transactional
//    public void addProductToOrder(Long orderId, Long productId) {
//        Order order;
//
//        if (orderId == 0) {
//            order = orderRepo.findById(0L)
//                    .orElse(null);
//        } else {
//            Optional<Order> existingOrder = orderRepo.findById(0L);
//            existingOrder.ifPresent(orderRepo::delete);
//            order = Order.builder()
//                    .id(0L)
//                    .orderDate(LocalDateTime.now())
//                    .temporaryPrice(0.0)
//                    .totalDiscount(0.0)
//                    .totalPrice(0.0)
//                    .items(new ArrayList<>())
//                    .build();
//        }
//
//        Product product = productRepo.findById(productId)
//                .orElseThrow(() -> new EntityNotFoundException("Product not found with id: " + productId));
//
//
//        OrderItem existingOrderItem = order.getItems().stream()
//                .filter(item -> item.getProducts().getId().equals(productId)) // Sửa lại thành item.getProduct().getId()
//                .findFirst()
//                .orElse(null);
//        if (existingOrderItem != null) {
//
//            existingOrderItem.setQuantity(existingOrderItem.getQuantity() + 1);
//        } else {
//            OrderItem orderItem = OrderItem.builder()
//                    .name(product.getName())
//                    .price(product.getPrice())
//                    .discount(product.getDiscount())
//                    .sumPrice(product.getSumPrice())
//                    .quantity(1)
//                    .description(product.getDescription())
//                    .isFavorite(product.isFavorite())
//                    .build();
//            order.getItems().add(orderItem);
//        }
//
//        CalculatePrices calculatedPrices = calculatorPrices(order);
//        order.setTemporaryPrice(calculatedPrices.getTemporaryPrice());
//        order.setTotalDiscount(calculatedPrices.getTotalDiscount());
//        order.setTotalPrice(calculatedPrices.getTotalPrice());
//        orderRepo.save(order);
//    }
//
//    private CalculatePrices calculatorPrices(Order order){
//        double temporaryPrice = 0.0;
//        double totalPrice = 0.0;
//
//        List<OrderItem> items = order.getItems();
//
//        for (OrderItem item : items) {
//            double itemPrice =(double) item.getPrice();
//            double itemSumPrice = (double) item.getSumPrice();
//
//            temporaryPrice += itemPrice;
//            totalPrice += itemSumPrice;
//    }
//        double totalDiscount = temporaryPrice / totalPrice;
//        return CalculatePrices.builder()
//                .temporaryPrice(temporaryPrice)
//                .totalDiscount(totalDiscount)
//                .totalPrice(totalPrice)
//                .build();
//}
//    @Transactional
//    public void removeProductFromOrder(Long orderId, Long productId) {
//        Optional<Order> optionalOrder = orderRepo.findById(0L);
//        if (optionalOrder.isPresent()) {
//            Order order = optionalOrder.get();
//
//            order.getItems().removeIf(item -> item.getId().equals(productId));
//
//            CalculatePrices calculatedPrices = calculatorPrices(order);
//            order.setTemporaryPrice(calculatedPrices.getTemporaryPrice());
//            order.setTotalDiscount(calculatedPrices.getTotalDiscount());
//            order.setTotalPrice(calculatedPrices.getTotalPrice());
//
//            orderRepo.save(order);
//        } else {
//            throw new EntityNotFoundException("Order not found with id: " + orderId);
//        }
//    }
//
//    @Override
//    public void getAllProductsFromOrder(Long orderId) {
//        Order order = orderRepo
//                .findById(orderId).orElseThrow(
//                        () -> new EntityNotFoundException("Order not found with id: " + orderId));
//        List<OrderItem> items = order.getItems();
//    }
//}
